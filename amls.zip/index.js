// index.js (VERSI FINAL DENGAN STABILITAS, FILTER LOG, DAN UI MODERN)

// --- INISIALISASI & IMPORT ---
const TelegramBot = require('node-telegram-bot-api');
const nodemailer = require('nodemailer');
const fs = require('fs');
const qrcode = require('qrcode');
const WhatsAppChecker = require('./whatsapp-checker.js');

// --- KONSTANTA & KONFIGURASI ---
const TOKEN = '7624566109:AAHnAXGE8opS74dM6SnXo7GfpA77PALrVsI'; // GANTI DENGAN TOKEN ASLI ANDA
const ADMIN_PASSWORD = 'Ryuuzaki13.'; // GANTI DENGAN PASSWORD ASLI ANDA
const CONFIG_FILE = 'config.json';
const bot = new TelegramBot(TOKEN, { polling: true });

const userState = {};
const adminState = {};
const authorizedUsers = {};

let config = {
  emailAccounts: [],
  emailIndex: 0,
  targetEmailDefault: ['support@whatsapp.com', 'smb@support.whatsapp.com', 'business@support.whatsapp.com', 'security@whatsapp.com'],
  imapSettings: { host: 'imap.gmail.com', port: 993, tls: true },
  templates: {
    UNLOCK_V1: { subject: 'Login Problem', body: 'Halo Tim Dukungan WhatsApp,\n\nSaya ingin melaporkan masalah terkait nomor WhatsApp saya. Saat mencoba melakukan pendaftaran, setiap kali saya ingin masuk selalu muncul pesan “Login Tidak Tersedia Saat Ini”, dan terkadang saya tidak menerima kode dari SMS.\n\nSaya sangat berharap pihak WhatsApp dapat membantu agar saya bisa menggunakan kembali nomor saya {{NOMOR_TELEPON}} tanpa muncul kendala tersebut.\n\nTerima kasih atas perhatian dan bantuannya.\n\nHormat saya,\nPengguna WhatsApp', input: ['nomor'], target: ['support@whatsapp.com', 'smb@support.whatsapp.com', 'business@support.whatsapp.com', 'security@whatsapp.com'] },
    UNLOCK_V2: { subject: 'Login Problem', body: 'سلام تیم پشتیبانی واتساپ،\n\nمیخواهم مشکلی را در رابطه با شماره واتساپ خود گزارش کنم. هنگام تلاش برای ثبتنام، هر بار که میخواهم وارد شوم، پیام «ورود در حال حاضر در دسترس نیست» ظاهر میشود و گاهی اوقات کد تأیید از طریق پیامک دریافت نمیکنم.\n\nامیدوارم تیم واتساپ بتواند کمک کند تا بتوانم دوباره بدون بروز این مشکل از شماره خ {{NOMOR_TELEFON}} استفاده کنم.\n\nاز توجه و همکاری شما سپاسگزارم.\n\nبا احترام .', input: ['nomor'], target: ['support@whatsapp.com', 'smb@support.whatsapp.com', 'business@support.whatsapp.com', 'security@whatsapp.com'] },
    UNBANNED_V1: { subject: 'Account Recovery Request', body: 'WhatsApp Support Team,\n\nMy name is {{NAMA_LENGKAP}}, and I have been a long-time user of WhatsApp. Unfortunately, my WhatsApp account associated with the number {{NOMOR_TELEPON}} was recently blocked. (Someone has used my WhatsApp account without my permission, and I kindly request that my account be restored.)\n\nThrough this support ticket, I sincerely hope that my blocked WhatsApp account can be recovered. I apologize for any mistakes I may have made while using the WhatsApp application, and I assure you that I will not repeat such mistakes in the future.\n\nThank you for your kind attention and consideration.\n\nRespectfully,\n{{NAMA_LENGKAP}}', input: ['nama', 'nomor'], target: ['support@whatsapp.com', 'smb@support.whatsapp.com', 'business@support.whatsapp.com', 'security@whatsapp.com'] },
    UNBANNED_V2: { subject: 'Account Recovery Request', body: 'Prezada equipe do WhatsApp,\n\nVenho por meio desta solicitar, com todo respeito e humildade, a reativação da minha conta associada ao número: {{NOMOR_TELEFON}}\n\nFui surpreendido com o bloqueio permanente da minha conta, mesmo sem ter violado, intencionalmente, nenhuma diretriz ou Termo de Serviço da plataforma. Caso alguma atividade tenha sido considerada inadequada, peço sinceras desculpas, pois jamais tive a intenção de infringir as regras.\n\nUtilizo esse número diariamente para me comunicar com minha família, clientes e colegas de trabalho. O WhatsApp é uma ferramenta essencial na minha vida pessoal e profissional, e estou profundamente preocupado com a suspensão.\n\nPeço gentilmente que revisem minha situação e me concedam uma segunda chance. Comprometo-me a seguir todas as normas da plataforma com responsabilidade daqui pra frente.\n\nAgradeço pela atenção e compreensão. Aguardo ansiosamente uma resposta positiva.\n\nAtenciosamente,\nJoão Henrique da Silva', input: ['nomor'], target: ['support@whatsapp.com', 'smb@support.whatsapp.com', 'business@support.whatsapp.com', 'security@whatsapp.com'] },
  },
  adminPassword: ADMIN_PASSWORD,
};

// --- INISIALISASI WHATSAPP CHECKER ---
const waChecker = new WhatsAppChecker({
  onStatus: (chatId, message) => bot.sendMessage(chatId, `ℹ️ _${message}_`, { parse_mode: 'Markdown' }),
  onQR: async (chatId, qr) => {
    const qrBuffer = await qrcode.toBuffer(qr);
    bot.sendPhoto(chatId, qrBuffer, { caption: 'Pindai QR ini untuk login.' });
  },
  onPairingCode: (chatId, code) => bot.sendMessage(chatId, `✅ *Pairing Code Anda:*\n\n\`${code}\`\n\nMasukkan di opsi "Tautkan dengan nomor telepon".`, { parse_mode: 'Markdown' }),
  onConnected: (chatId, userName) => bot.sendMessage(chatId, `✅ *Berhasil Terhubung!* \nSelamat datang, ${userName}.`, { parse_mode: 'Markdown' }),
  onDisconnected: (chatId, shouldReconnect) => {
    let message = '🔴 *Koneksi WhatsApp Terputus.*';
    message += shouldReconnect ? '\nMencoba menyambungkan ulang...' : '\nSesi tidak valid. Hubungkan kembali manual.';
    bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  },
  onReportUpdate: async (chatId, msgKey, text) => {
    try {
      if (msgKey) {
        await bot.editMessageText(text, { chat_id: chatId, message_id: msgKey.message_id, parse_mode: 'Markdown' });
        return msgKey;
      } else {
        const sent = await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
        return { message_id: sent.message_id };
      }
    } catch (e) {
      if (e.message.includes('message is not modified')) return msgKey;
      const sent = await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
      return { message_id: sent.message_id };
    }
  },
  onCheckingComplete: (chatId, filePath) => bot.sendMessage(chatId, `🎉 **Pengecekan Selesai!**\nFile hasil (\`${filePath}\`) telah dibuat.`, { parse_mode: 'Markdown' }),
  onProgressUpdate: async (chatId, msgId, text) => {
    if (msgId) {
      await bot.editMessageText(text, { chat_id: chatId, message_id: msgId, parse_mode: 'Markdown' });
      return { message_id: msgId };
    } else {
      const sent = await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
      return { message_id: sent.message_id };
    }
  },
});

// --- FUNGSI UTILITAS & EMAIL ---
function loadConfig() {
  try {
    const data = fs.readFileSync(CONFIG_FILE);
    config = { ...config, ...JSON.parse(data) };
    console.log('Konfigurasi dimuat.');
  } catch (error) {
    console.log('File konfigurasi tidak ditemukan, pakai default.');
    saveConfig();
  }
}

function saveConfig() {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

function cleanNumberInput(input) {
  if (!input) return '';
  return '+' + input.replace(/[^0-9]/g, '');
}

async function sendEmailRoundRobin(templateKey, userData) {
  const template = config.templates[templateKey];
  if (!template) throw new Error('Template tidak ditemukan.');
  if (config.emailAccounts.length === 0) throw new Error('Tidak ada akun email yang terdaftar.');

  const targetEmails = template.target?.length ? template.target : config.targetEmailDefault;
  const account = config.emailAccounts[config.emailIndex % config.emailAccounts.length];
  config.emailIndex = (config.emailIndex + 1) % config.emailAccounts.length;
  saveConfig();

  let body = template.body.replace(/{{NOMOR_TELEPON}}|{{NOMOR_TELEFON}}/g, cleanNumberInput(userData.nomor));
  if (userData.nama) {
    body = body.replace(/{{NAMA_LENGKAP}}/g, userData.nama);
  }

  const transporter = nodemailer.createTransport({ service: 'gmail', auth: { user: account.user, pass: account.pass } });

  return new Promise((resolve, reject) => {
    transporter.sendMail({ from: account.user, to: targetEmails.join(','), subject: template.subject, text: body }, (error, info) => {
      if (error) {
        reject(error);
      } else {
        resolve(`Email berhasil dikirim via **${account.user}**.`);
      }
    });
  });
}

// --- DEFINISI KEYBOARD ---
const MainMenuKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '💌 Kirim Email Bantuan', callback_data: 'SHOW_ACTIONS' }],
      [{ text: '📊 Cek Nomor WhatsApp', callback_data: 'WA_MENU' }],
      [{ text: '💬 Cek Bio WhatsApp', callback_data: 'BIO_MENU' }],
      [{ text: '⚙️ Panel Admin', callback_data: 'SHOW_ADMIN_LOGIN' }],
    ],
  },
};

const ActionMenuKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '🔓 UNLOCK V1 🇮🇩', callback_data: 'START_UNLOCK_V1' }, { text: '🔓 UNLOCK V2 🇮🇷', callback_data: 'START_UNLOCK_V2' }],
      [{ text: '🚫 UNBANNED V1 🇬🇧', callback_data: 'START_UNBANNED_V1' }, { text: '🚫 UNBANNED V2 🇧🇷', callback_data: 'START_UNBANNED_V2' }],
      [{ text: '⬅️ Kembali', callback_data: 'SHOW_MAIN_MENU' }],
    ],
  },
};

function getWhatsAppMenuKeyboard() {
  const statusText = waChecker.isConnected ? '✅ Terhubung' : '🔴 Terputus';
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🚀 Pengecekan Massal (File)', callback_data: 'WA_START_CHECK' }],
        [{ text: '📷 Hubungkan (QR)', callback_data: 'WA_CONNECT_QR' }, { text: '📲 Hubungkan (Pairing)', callback_data: 'WA_CONNECT_PAIRING' }],
        [{ text: `ℹ️ Status: ${statusText}`, callback_data: 'WA_STATUS' }, { text: '🚪 Logout', callback_data: 'WA_LOGOUT' }],
        [{ text: '⬅️ Kembali ke Menu Utama', callback_data: 'SHOW_MAIN_MENU' }],
      ],
    },
  };
}

const BioMenuKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '👤 Cek Bio Tunggal', callback_data: 'BIO_CHECK_SINGLE' }],
      [{ text: '🗂️ Cek Bio Massal (File)', callback_data: 'BIO_CHECK_BULK' }],
      [{ text: '⬅️ Kembali ke Menu Utama', callback_data: 'SHOW_MAIN_MENU' }],
    ],
  },
};

// --- EVENT HANDLERS ---
bot.onText(/\/start|\/menu/, (msg) => {
  const chatId = msg.chat.id;
  const firstName = msg.from.first_name || 'Kawan';

  if (authorizedUsers[chatId]) {
    const welcomeMessage = `
🚀 Halo, *${firstName}!* Selamat datang kembali.

Saya adalah asisten multifungsi Anda, siap membantu dengan berbagai keperluan:
🔹 *Kirim Email Bantuan* ke Dukungan WhatsApp.
🔹 *Validasi Nomor WA* secara massal.
🔹 *Cek Bio & Status* akun WhatsApp.

Pilih salah satu menu di bawah untuk memulai.
        `;
    bot.sendMessage(chatId, welcomeMessage, { parse_mode: 'Markdown', ...MainMenuKeyboard });
  } else {
    const loginMessage = `
🔒 *Akses Terbatas*

Halo, ${firstName}! Untuk menggunakan bot ini, silakan masukkan *kata sandi* yang telah diberikan.
        `;
    bot.sendMessage(chatId, loginMessage, { parse_mode: 'Markdown' });
  }
});

bot.on('callback_query', async (cbq) => {
  const { data, message } = cbq;
  const { chat, message_id } = message;
  
  if (!['WA_STATUS'].includes(data)) {
    bot.deleteMessage(chat.id, message_id).catch(() => {});
  }

  if (!authorizedUsers[chat.id]) {
    return bot.sendMessage(chat.id, '🔐 Silakan masukkan **kata sandi** untuk melanjutkan:');
  }
  
  try {
    if (data === 'SHOW_ADMIN_LOGIN') showAdminMenu(chat.id, '🔐 **Admin Panel**');
    else if (data.startsWith('WA_')) await handleWhatsAppCallback(chat.id, data);
    else if (data.startsWith('BIO_')) await handleBioCallback(chat.id, data);
    else if (data.startsWith('ADMIN_')) await handleAdminCallback(chat.id, data);
    else if (data.startsWith('START_')) await handleEmailActionCallback(chat.id, data);
    else if (data === 'SHOW_MAIN_MENU') bot.sendMessage(chat.id, '➡️ **Menu Utama**', { parse_mode: 'Markdown', ...MainMenuKeyboard });
    else if (data === 'SHOW_ACTIONS') bot.sendMessage(chat.id, 'Pilih jenis aksi:', ActionMenuKeyboard);
  } catch (error) {
    console.error(`Error pada callback_query [${data}]:`, error);
    bot.sendMessage(chat.id, `❌ Terjadi kesalahan saat memproses permintaan Anda.`);
  }
});

bot.on("message", async (msg) => {
  const { chat, text, document } = msg;

  try {
    if (document || !text || text.startsWith("/")) return;

    if (!authorizedUsers[chat.id]) {
      if (text === config.adminPassword) {
        authorizedUsers[chat.id] = true;
        bot.sendMessage(chat.id, "✅ **Login Berhasil!**", { parse_mode: 'Markdown' });
        bot.emit('message', { ...msg, text: '/start' });
      } else {
        bot.sendMessage(chat.id, "❌ **Kata sandi salah.**");
      }
      return;
    }

    if (adminState[chat.id]) await handleAdminInput(chat.id, text);
    else if (userState[chat.id]) await handleUserInput(chat.id, text);
    else bot.sendMessage(chat.id, '🤔 Perintah tidak dikenali.', MainMenuKeyboard);
  } catch (error) {
    console.error(`Error fatal pada message handler:`, error);
    bot.sendMessage(chat.id, `❌ **Terjadi Kesalahan Kritis!**\nBot mengalami masalah saat memproses pesan Anda. Silakan coba lagi nanti.`);
  }
});

bot.on('document', async (msg) => {
  const { chat, document } = msg;
  const state = adminState[chat.id];

  if (!state || (state.step !== 'WA_WAITING_FILE' && state.step !== 'WA_WAITING_BIO_FILE')) return;
  if (document.file_name !== 'nomor.txt') return bot.sendMessage(chat.id, '❌ File salah. Harap unggah file `nomor.txt`.');

  bot.sendMessage(chat.id, '✅ File diterima. Memproses...');
  const filePath = await bot.downloadFile(document.file_id, './');
  const numbers = fs.readFileSync(filePath, 'utf-8').split('\n').map(l => l.trim()).filter(Boolean);
  fs.unlinkSync(filePath);
  
  if (numbers.length === 0) return bot.sendMessage(chat.id, '❌ File `nomor.txt` kosong!');

  const currentStep = state.step;
  delete adminState[chat.id]; 

  try {
    if (currentStep === 'WA_WAITING_FILE') {
      bot.sendMessage(chat.id, `Memulai pengecekan massal untuk ${numbers.length} nomor...`);
      await waChecker.checkNumbers(numbers);
    } else if (currentStep === 'WA_WAITING_BIO_FILE') {
      await waChecker.checkBiosBulk(numbers);
    }
  } catch (error) {
    console.error('Terjadi error fatal saat pengecekan:', error);
    bot.sendMessage(chat.id, `❌ **Terjadi Kesalahan Kritis!**\n\nProses pengecekan dihentikan. Silakan periksa status koneksi dan coba lagi.\n\n\`\`\`${error.message}\`\`\``, { parse_mode: 'Markdown' });
  } finally {
    if (adminState[chat.id]) delete adminState[chat.id];
  }
});

// --- LOGIKA PEMROSESAN INPUT & CALLBACK ---
async function handleWhatsAppCallback(chatId, data) {
  if (data === 'WA_MENU') {
    bot.sendMessage(chatId, 'Pilih aksi untuk Pengecek Nomor WhatsApp:', getWhatsAppMenuKeyboard());
  } else if (data === 'WA_CONNECT_QR') {
    if (waChecker.isConnected) return bot.sendMessage(chatId, '✅ Anda sudah terhubung.');
    bot.sendMessage(chatId, '🔄 Mempersiapkan QR Code...');
    waChecker.connect(chatId, false);
  } else if (data === 'WA_CONNECT_PAIRING') {
    if (waChecker.isConnected) return bot.sendMessage(chatId, '✅ Anda sudah terhubung.');
    adminState[chatId] = { step: 'WA_WAITING_PHONE' };
    waChecker.connect(chatId, true);
  } else if (data === 'WA_LOGOUT') {
    const message = await waChecker.logout();
    bot.sendMessage(chatId, message);
  } else if (data === 'WA_STATUS') {
    const statusMsg = waChecker.isConnected ? `✅ *Status: Terhubung*\nNama: ${waChecker.client.user.name}` : '🔴 *Status: Terputus*';
    bot.sendMessage(chatId, statusMsg, { parse_mode: 'Markdown' });
  } else if (data === 'WA_START_CHECK') {
    if (!waChecker.isConnected) return bot.sendMessage(chatId, '❌ Hubungkan ke WhatsApp dulu!');
    if (waChecker.isChecking) return bot.sendMessage(chatId, '⏳ Pengecekan lain sedang berlangsung.');
    adminState[chatId] = { step: 'WA_WAITING_FILE' };
    bot.sendMessage(chatId, 'Silakan unggah file `nomor.txt` Anda.');
  }
}

async function handleBioCallback(chatId, data) {
  if (!waChecker.isConnected) return bot.sendMessage(chatId, '❌ Hubungkan ke WhatsApp dulu!');
  
  if (data === 'BIO_MENU') {
    bot.sendMessage(chatId, 'Pilih metode pengecekan bio:', BioMenuKeyboard);
  } else if (data === 'BIO_CHECK_SINGLE') {
    adminState[chatId] = { step: 'WA_WAITING_BIO_NUMBER' };
    bot.sendMessage(chatId, '📝 Masukkan satu nomor WhatsApp untuk dicek bionya:');
  } else if (data === 'BIO_CHECK_BULK') {
    adminState[chatId] = { step: 'WA_WAITING_BIO_FILE' };
    bot.sendMessage(chatId, '🗂️ Silakan unggah file `nomor.txt` berisi daftar nomor untuk dicek bionya.');
  }
}

async function handleEmailActionCallback(chatId, data) {
  const action = data.replace('START_', '');
  const template = config.templates[action];
  if (!template) return;

  userState[chatId] = {
    action: action,
    inputFields: template.input,
    currentStepIndex: 0,
    data: {},
  };
  
  const firstField = template.input[0];
  const prompt = firstField === 'nama' ? '📝 Masukkan **Nama Lengkap** Anda:' : '📝 Masukkan **Nomor WhatsApp** Anda:';
  bot.sendMessage(chatId, prompt, { parse_mode: 'Markdown' });
}

async function handleUserInput(chatId, text) {
  const state = userState[chatId];
  const currentField = state.inputFields[state.currentStepIndex];
  state.data[currentField] = text;
  state.currentStepIndex++;

  if (state.currentStepIndex < state.inputFields.length) {
    const nextField = state.inputFields[state.currentStepIndex];
    const prompt = nextField === 'nama' ? '📝 Masukkan **Nama Lengkap** Anda:' : '📝 Masukkan **Nomor WhatsApp** Anda:';
    bot.sendMessage(chatId, prompt, { parse_mode: 'Markdown' });
  } else {
    bot.sendMessage(chatId, '📡 **Memproses & Mengirim...**', { parse_mode: 'Markdown' });
    try {
      const resultMessage = await sendEmailRoundRobin(state.action, state.data);
      bot.sendMessage(chatId, `🎉 **Berhasil!**\n\n${resultMessage}`, { parse_mode: 'Markdown' });
    } catch (error) {
      bot.sendMessage(chatId, `❌ **Gagal:** ${error.message}`, { parse_mode: 'Markdown' });
    } finally {
      delete userState[chatId];
      bot.sendMessage(chatId, '✅ **Selesai.**', ActionMenuKeyboard);
    }
  }
}

async function handleAdminInput(chatId, text) {
  const state = adminState[chatId];
  if (!state) return;

  if (state.step === 'WA_WAITING_BIO_NUMBER') {
    bot.sendMessage(chatId, `⏳ Memeriksa bio *${text}*...`, { parse_mode: 'Markdown' });
    const result = await waChecker.checkBio(text);
    bot.sendMessage(chatId, result, { parse_mode: 'Markdown' });
    delete adminState[chatId];
    return;
  }

  if (state.step === 'WA_WAITING_PHONE') {
    const phoneNumber = text.replace(/\D/g, '');
    if (phoneNumber.length >= 9 && phoneNumber.length <= 15) {
      bot.sendMessage(chatId, `Meminta pairing code untuk +${phoneNumber}...`);
      await waChecker.requestPairingCode(phoneNumber);
      delete adminState[chatId];
    } else {
      bot.sendMessage(chatId, '❌ Format tidak valid. Masukkan nomor lengkap dengan kode negara.');
    }
    return;
  }

  if (state.step === 'ADMIN_INPUT_EMAIL') {
    state.data.user = text.trim();
    state.step = 'ADMIN_INPUT_PASSWORD';
    bot.sendMessage(chatId, 'Masukkan **App Password** Gmail:');
    return;
  }

  if (state.step === 'ADMIN_INPUT_PASSWORD') {
    state.data.pass = text.trim();
    config.emailAccounts.push(state.data);
    saveConfig();
    delete adminState[chatId];
    showAdminMenu(chatId, `✅ Akun **${state.data.user}** ditambahkan!`);
    return;
  }
}

async function handleAdminCallback(chatId, data) {
  if (data === 'ADMIN_SHOW_MENU') {
    showAdminMenu(chatId, '↩️ Kembali ke Menu Admin.');
    return;
  }

  if (data === 'ADMIN_MANAGE_ACCOUNTS') {
    let msg = '📋 **Daftar Akun Email Aktif:**\n';
    if (config.emailAccounts.length === 0) {
      msg += 'Tidak ada akun terdaftar.';
    } else {
      config.emailAccounts.forEach((acc, index) => {
        const nextIndex = config.emailAccounts.length > 0 ? config.emailIndex % config.emailAccounts.length : -1;
        const isNext = (index === nextIndex) ? '➡️' : '  ';
        msg += `\n${isNext} \`#${index + 1}\`: \`${acc.user}\``;
      });
    }
    const accKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '➕ Tambah Akun Baru', callback_data: 'ADMIN_ADD_ACCOUNT' }],
          [{ text: '➖ Hapus Akun (by Index)', callback_data: 'ADMIN_DELETE_ACCOUNT' }],
          [{ text: '⬅️ Kembali ke Menu Admin', callback_data: 'ADMIN_SHOW_MENU' }],
        ],
      },
    };
    bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', ...accKeyboard, disable_web_page_preview: true });
    return;
  }

  if (data === 'ADMIN_ADD_ACCOUNT') {
    adminState[chatId] = { step: 'ADMIN_INPUT_EMAIL', data: {} };
    bot.sendMessage(chatId, 'Masukkan **Alamat Email** (Contoh: `mail@gmail.com`):', { parse_mode: 'Markdown' });
    return;
  }
}

function showAdminMenu(chatId, message) {
  const nextAccountIndex = config.emailAccounts.length > 0 ? (config.emailIndex % config.emailAccounts.length) + 1 : 0;
  const stats = `**Ringkasan Sistem:**\n- 📧 Akun Aktif: ${config.emailAccounts.length}\n- 🎯 Target Default: ${config.targetEmailDefault.length} alamat\n- 🔄 Akun Selanjutnya: #${nextAccountIndex || 'N/A'}`;
  const adminKeyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: '📧 Kelola Akun Pengirim', callback_data: 'ADMIN_MANAGE_ACCOUNTS' }],
        [{ text: '📝 Kelola Template & Target', callback_data: 'ADMIN_MANAGE_TEMPLATES' }],
        [{ text: '🎯 Atur Target Default Global', callback_data: 'ADMIN_SET_DEFAULT_TARGETS' }],
        [{ text: '⚙️ Pengaturan IMAP', callback_data: 'ADMIN_IMAP_SETTINGS' }, { text: '🔑 Ganti Password Admin', callback_data: 'ADMIN_CHANGE_PASSWORD' }],
        [{ text: '🧪 Uji Kirim Email', callback_data: 'ADMIN_TEST_EMAIL' }, { text: '♻️ Reset Counter', callback_data: 'ADMIN_RESET_COUNTER' }],
        [{ text: '⬅️ Kembali ke Menu Utama', callback_data: 'SHOW_MAIN_MENU' }],
      ],
    },
  };
  bot.sendMessage(chatId, `## ${message}\n\n${stats}`, { parse_mode: 'Markdown', ...adminKeyboard, disable_web_page_preview: true });
}

// --- INISIALISASI BOT ---
loadConfig();
console.log('Bot Telegram Terintegrasi berjalan...');
