// whatsapp-checker.js (VERSI FINAL DENGAN FILTER LOG YANG DISEMPURNAKAN)

// --- INISIALISASI & IMPORT ---
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const fs = require("fs");

// --- KONSTANTA ---
const SESSION_DIR = "session";
const RESULTS_FILE = "not_registered_numbers.txt";
const DELAY_MS = 500;
const REALTIME_UPDATE_INTERVAL = 5;

// --- DEFINISI CLASS ---
class WhatsAppChecker {
  constructor(callbacks) {
    this.client = null;
    this.isConnected = false;
    this.isChecking = false;
    this.loginMethod = null;
    this.tgReportMessageKey = null;
    this.waReportMessageKey = null;
    this.startTime = null;
    this.ownerChatId = null;
    this.callbacks = callbacks;
    this.logBlacklist = ["message is too long", "message to edit not found"];

    if (!fs.existsSync(SESSION_DIR)) {
      fs.mkdirSync(SESSION_DIR, { recursive: true });
    }
  }

  log(level, message) {
    console.log(`[WhatsAppChecker] [${level.toUpperCase()}] ${message}`);

    const shouldSendMessage = !this.logBlacklist.some(term => message.toLowerCase().includes(term));

    if (this.ownerChatId && this.callbacks.onStatus && (level === 'error' || level === 'warn') && shouldSendMessage) {
      this.callbacks.onStatus(this.ownerChatId, `[${level.toUpperCase()}] ${message}`);
    }
  }

  async connect(chatId, usePairingCode = false) {
    this.ownerChatId = chatId;
    this.loginMethod = usePairingCode ? 'pairing' : 'qr';

    if (this.isConnected) {
      if (this.callbacks.onStatus) this.callbacks.onStatus(chatId, '✅ Anda sudah terhubung ke WhatsApp.');
      return;
    }

    const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
    const { version } = await fetchLatestBaileysVersion();

    this.client = makeWASocket({
      version,
      logger: pino({ level: "silent" }),
      printQRInTerminal: false,
      auth: state,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      getMessage: async (key) => ({ conversation: "WhatsApp Number Checker" }),
    });

    this.client.ev.on("creds.update", saveCreds);

    if (usePairingCode && !this.client.authState.creds.registered) {
      if (this.callbacks.onStatus) this.callbacks.onStatus(chatId, '🔐 Silakan masukkan nomor WhatsApp Anda (dengan kode negara) untuk mendapatkan pairing code.');
    }

    this.client.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr && this.callbacks.onQR && this.loginMethod === 'qr') {
        this.callbacks.onQR(chatId, qr);
      }

      if (connection === "close") {
        this.isConnected = false;
        const shouldReconnect = (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut);
        this.log('error', `Koneksi terputus: ${lastDisconnect?.error?.output?.statusCode || 'Unknown'}. Reconnect: ${shouldReconnect}`);
        if (this.callbacks.onDisconnected) this.callbacks.onDisconnected(chatId, shouldReconnect);
        if (shouldReconnect) {
          setTimeout(() => this.connect(chatId, usePairingCode), 3000);
        }
      } else if (connection === "open") {
        this.isConnected = true;
        this.log('info', `Berhasil terhubung ke WhatsApp sebagai ${this.client.user?.name}!`);
        if (this.callbacks.onConnected) this.callbacks.onConnected(chatId, this.client.user?.name || 'Unknown');
      }
    });
  }

  async requestPairingCode(phoneNumber) {
    if (!this.client) return this.log('error', 'Client belum diinisialisasi.');
    try {
      const code = await this.client.requestPairingCode(phoneNumber);
      if (this.callbacks.onPairingCode) this.callbacks.onPairingCode(this.ownerChatId, code);
    } catch (error) {
      this.log('error', `Gagal meminta pairing code: ${error.message}`);
      if (this.callbacks.onStatus) this.callbacks.onStatus(this.ownerChatId, `❌ Gagal: ${error.message}.`);
    }
  }

  async logout() {
    if (!this.isConnected) return "Tidak ada koneksi aktif.";
    await this.client.logout();
    this.isConnected = false;
    this.loginMethod = null;
    if (fs.existsSync(SESSION_DIR)) {
      fs.rmSync(SESSION_DIR, { recursive: true, force: true });
    }
    return "✅ Logout berhasil dan session telah dihapus.";
  }

  async checkBio(phoneNumber) {
    if (!this.isConnected) return "❌ Gagal: Anda tidak terhubung ke WhatsApp.";

    try {
      const cleaned = phoneNumber.replace(/\D/g, "");
      if (cleaned.length < 8) return "❌ Nomor tidak valid.";
      const jid = `${cleaned}@s.whatsapp.net`;

      const [onWhatsApp] = await this.client.onWhatsApp(jid) || [];
      if (!onWhatsApp?.exists) {
        return `❌ Nomor *+${cleaned}* tidak terdaftar di WhatsApp.`;
      }

      try {
        const result = await this.client.fetchStatus(jid);
        if (result && result.status) {
          const date = new Date(result.setAt);
          const formattedDate = date.toLocaleString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
          return `✅ *Nomor Aktif dengan Bio:*\n1. +${cleaned}\n\n📝 *Bio:*\n${result.status}\n\n📅 *Update Terakhir:*\n${formattedDate}`;
        } else {
          return `✅ *Nomor Aktif Tanpa Bio:*\n1. +${cleaned}`;
        }
      } catch (fetchError) {
        const errorMessage = (fetchError.message || "").toLowerCase();
        if (errorMessage.includes('404') || errorMessage.includes('item-not-found')) {
          return `✅ *Nomor Aktif, Bio Privat:*\n1. +${cleaned}\n\n(Bio tidak dapat ditampilkan, kemungkinan karena pengaturan privasi).`;
        }
        throw fetchError;
      }
    } catch (error) {
      this.log('error', `Gagal cek bio untuk ${phoneNumber}: ${error.message}`);
      return `❌ Terjadi kesalahan saat memeriksa bio untuk *${phoneNumber}*.`;
    }
  }

  async checkBiosBulk(numbers) {
    if (!this.isConnected) return this.callbacks.onStatus(this.ownerChatId, "❌ Gagal: Anda tidak terhubung ke WhatsApp.");

    let report = "📝 *Laporan Cek Bio Massal*\n\n";
    const total = numbers.length;
    const msg = await this.callbacks.onProgressUpdate(this.ownerChatId, null, `⏳ Memeriksa 0 dari ${total} nomor...`);

    for (let i = 0; i < total; i++) {
      const number = numbers[i];
      const cleaned = number.replace(/\D/g, "");
      if (!cleaned) continue;

      const jid = `${cleaned}@s.whatsapp.net`;
      try {
        const [onWhatsApp] = await this.client.onWhatsApp(jid) || [];
        if (onWhatsApp?.exists) {
          const status = await this.client.fetchStatus(jid);
          report += `✅ *+${cleaned}*:\n${status.status ? '└─ ' + status.status.replace(/\n/g, ' ') + '\n' : '└─ (Tidak ada bio)\n'}`;
        } else {
          report += `❌ *+${cleaned}*: Tidak Terdaftar\n`;
        }
      } catch (e) {
        report += `⚠️ *+${cleaned}*: Error\n`;
      }

      if ((i + 1) % 5 === 0 || (i + 1) === total) {
        await this.callbacks.onProgressUpdate(this.ownerChatId, msg.message_id, `⏳ Memeriksa ${i + 1} dari ${total} nomor...`);
      }
      await new Promise(r => setTimeout(r, 200));
    }
    await this.callbacks.onProgressUpdate(this.ownerChatId, msg.message_id, report);
  }

  async checkNumbers(numbers) {
    if (!this.isConnected || !this.client.user) return this.log('error', 'Tidak terhubung ke WhatsApp.');
    if (this.isChecking) return this.log('warn', 'Pengecekan lain sedang berlangsung.');

    this.isChecking = true;
    this.startTime = new Date();
    this.tgReportMessageKey = null;
    this.waReportMessageKey = null;
    const selfJid = this.client.user.id;

    try {
      const initialReport = this.generateRealtimeReportText([], 0, numbers.length, 0, 0, 0, false);
      if (this.callbacks.onReportUpdate) this.tgReportMessageKey = await this.callbacks.onReportUpdate(this.ownerChatId, null, initialReport);
      
      const waMsg = await this.client.sendMessage(selfJid, { text: initialReport });
      this.waReportMessageKey = waMsg.key;
      
      let usableCount = 0, notFoundCount = 0, errorCount = 0;
      const checkedNumbers = [];

      for (let i = 0; i < numbers.length; i++) {
        const originalNumber = numbers[i];
        try {
          const cleaned = originalNumber.replace(/\D/g, "");
          if (cleaned.length < 8 || cleaned.length > 15) {
            errorCount++;
          } else {
            const jid = `${cleaned}@s.whatsapp.net`;
            const [result] = await this.client.onWhatsApp(jid) || [];
            const countryInfo = this.getCountryInfo(cleaned);

            if (result?.exists) {
              let isUsable = true;
              try {
                await this.client.presenceSubscribe(jid);
                await new Promise(r => setTimeout(r, 200));
              } catch (e) {
                if (e.message.includes('403') || e.message.includes('404') || e.message.includes('401')) {
                  isUsable = false;
                }
              }

              const hasProfile = isUsable ? await this.checkProfilePicture(jid) : false;
              const statusEmoji = isUsable ? '💸' : '🗿';
              checkedNumbers.push({ number: cleaned, hasProfile, isUsable, statusEmoji, country: countryInfo.name, flag: countryInfo.flag });
              
              if (isUsable) {
                usableCount++;
              } else {
                errorCount++;
                fs.appendFileSync(RESULTS_FILE, `+${cleaned} | Status: Banned/Inactive ${statusEmoji}\n`);
              }
            } else {
              fs.appendFileSync(RESULTS_FILE, `+${cleaned} | Negara: ${countryInfo.name} ${countryInfo.flag} | Status: Not Registered\n`);
              notFoundCount++;
            }
          }

          if ((i + 1) % REALTIME_UPDATE_INTERVAL === 0 || i === numbers.length - 1) {
            const reportText = this.generateRealtimeReportText(checkedNumbers, i + 1, numbers.length, usableCount, notFoundCount, errorCount, false);
            if (this.callbacks.onReportUpdate && this.tgReportMessageKey) await this.callbacks.onReportUpdate(this.ownerChatId, this.tgReportMessageKey, reportText);
            if (this.waReportMessageKey) await this.client.sendMessage(selfJid, { text: reportText, edit: this.waReportMessageKey });
          }

          await new Promise(r => setTimeout(r, DELAY_MS));
        } catch (error) {
          errorCount++;
          this.log('error', `Error saat cek ${originalNumber}: ${error.message}`);
        }
      }

      const finalReport = this.generateRealtimeReportText(checkedNumbers, numbers.length, numbers.length, usableCount, notFoundCount, errorCount, true);
      if (this.callbacks.onReportUpdate && this.tgReportMessageKey) await this.callbacks.onReportUpdate(this.ownerChatId, this.tgReportMessageKey, finalReport);
      if (this.waReportMessageKey) await this.client.sendMessage(selfJid, { text: finalReport, edit: this.waReportMessageKey });

    } finally {
      this.isChecking = false;
      if (this.callbacks.onCheckingComplete) this.callbacks.onCheckingComplete(this.ownerChatId, RESULTS_FILE);
    }
  }

  async checkProfilePicture(jid) {
    try {
      const ppUrl = await this.client.profilePictureUrl(jid, 'image');
      return !!ppUrl;
    } catch (error) {
      const errorMessage = (error.message || "").toLowerCase();
      if (!errorMessage.includes('item-not-found') && !errorMessage.includes('404') && !errorMessage.includes('not-authorized')) {
        this.log('error', `Gagal mendapatkan foto profil ${jid}: ${error.message}`);
      }
      return false;
    }
  }
  
  // --- FUNGSI HELPERS ---
  formatDuration(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }

  getCountryInfo(number) {
    const countryCodes = {
      '62': { name: 'Indonesia', flag: '🇮🇩' }, '1': { name: 'United States', flag: '🇺🇸' }, '7': { name: 'Russia', flag: '🇷🇺' }, '20': { name: 'Egypt', flag: '🇪🇬' }, '27': { name: 'South Africa', flag: '🇿🇦' },
      '30': { name: 'Greece', flag: '🇬🇷' }, '31': { name: 'Netherlands', flag: '🇳🇱' }, '32': { name: 'Belgium', flag: '🇧🇪' }, '33': { name: 'France', flag: '🇫🇷' }, '34': { name: 'Spain', flag: '🇪🇸' },
      '36': { name: 'Hungary', flag: '🇭🇺' }, '39': { name: 'Italy', flag: '🇮🇹' }, '40': { name: 'Romania', flag: '🇷🇴' }, '41': { name: 'Switzerland', flag: '🇨🇭' }, '43': { name: 'Austria', flag: '🇦🇹' },
      '44': { name: 'United Kingdom', flag: '🇬🇧' }, '45': { name: 'Denmark', flag: '🇩🇰' }, '46': { name: 'Sweden', flag: '🇸🇪' }, '47': { name: 'Norway', flag: '🇳🇴' }, '48': { name: 'Poland', flag: '🇵🇱' },
      '49': { name: 'Germany', flag: '🇩🇪' }, '51': { name: 'Peru', flag: '🇵🇪' }, '52': { name: 'Mexico', flag: '🇲🇽' }, '53': { name: 'Cuba', flag: '🇨🇺' }, '54': { name: 'Argentina', flag: '🇦🇷' },
      '55': { name: 'Brazil', flag: '🇧🇷' }, '56': { name: 'Chile', flag: '🇨🇱' }, '57': { name: 'Colombia', flag: '🇨🇴' }, '58': { name: 'Venezuela', flag: '🇻🇪' }, '60': { name: 'Malaysia', flag: '🇲🇾' },
    };
    const sortedCodes = Object.keys(countryCodes).sort((a, b) => b.length - a.length);
    for (const code of sortedCodes) {
      if (number.startsWith(code)) {
        return countryCodes[code];
      }
    }
    return { name: 'Unknown', flag: '🏳️' };
  }

  groupByCountry(registeredNumbers) {
    const groups = {};
    const usableNumbers = registeredNumbers.filter(n => n.isUsable);
    usableNumbers.forEach(item => {
      const key = item.country;
      if (!groups[key]) {
        groups[key] = { name: item.country, flag: item.flag, numbers: [] };
      }
      groups[key].numbers.push(item);
    });
    return groups;
  }

  generateRealtimeReportText(checkedNumbers, current, total, usable, notFound, error, isFinal) {
    const now = new Date();
    const time = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const percentage = total > 0 ? Math.round((current / total) * 100) : 0;
    const status = isFinal ? '*FINAL* 🎉' : '*LIVE* ⚡';
    const prefix = isFinal ? '✨ L A P O R A N   A K H IR' : '📊 L A P O R A N   R E A L T I M E';
    const progressBar = '█'.repeat(Math.floor(percentage / 10)) + '░'.repeat(10 - Math.floor(percentage / 10));

    let report = `*${prefix}* ${status}\n═══════════════════════\n\n`;
    report += `*PROGRESS* [ ${progressBar} ] ${percentage}%\n`;
    report += `• Total Dicek: ${current} / ${total}\n`;
    report += `➡️ Sisa Antrian: *${total - current}*\n\n`;
    report += `*RINGKASAN STATUS*\n═══════════════════════\n`;
    report += `💸 *Usable/Aktif*: *${usable}*\n`;
    report += `🗿 *Banned/Inactive*: *${error}*\n`;
    report += `❌ *Tidak Terdaftar*: *${notFound}*\n\n`;

    if (usable > 0) {
      const countryGroups = this.groupByCountry(checkedNumbers);
      const withProfileCount = checkedNumbers.filter(n => n.isUsable && n.hasProfile).length;
      report += `*DETAIL AKUN USABLE (${usable} Nomor)*\n═══════════════════════\n`;
      report += `📷 Dengan Foto Profil: *${withProfileCount}*\n\n`;

      Object.keys(countryGroups).sort().forEach(countryName => {
        const group = countryGroups[countryName];
        const withPhoto = group.numbers.filter(item => item.hasProfile);
        const withoutPhoto = group.numbers.filter(item => !item.hasProfile);

        report += `${group.flag} *${countryName}* (${group.numbers.length} usable)\n`;

        withPhoto.forEach(item => {
          report += `${item.statusEmoji} +${item.number} 📷\n`;
        });

        if (withPhoto.length > 0 && withoutPhoto.length > 0) {
          report += `   --------------------\n`;
        }

        withoutPhoto.forEach(item => {
          report += `${item.statusEmoji} +${item.number} 👤\n`;
        });
        report += `\n`;
      });
    }

    if (isFinal) {
      if (this.startTime) {
        report += `*🕒 DURASI TOTAL*: ${this.formatDuration(now.getTime() - this.startTime.getTime())}\n\n`;
      }
      report += `*FILE OUTPUT*\n═══════════════════════\n`;
      report += `Nomor *Tidak Terdaftar* & *Banned* disimpan di server dalam file: \`${RESULTS_FILE}\`\n\n`;
    }

    report += `_Update terakhir: ${time}_`;
    return report;
  }
}

module.exports = WhatsAppChecker;
